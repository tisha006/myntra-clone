10% Instant Discount on American Express Cards on a min spend of Rs 3,500 TCA
10% Instant Discount on Kotak Credit and Debit cards on a min spend of Rs 3,000 TCA
5% Unlimited Cashback on Flipkart Axis Bank Credit Card TCA
15% Cashback upto Rs 150 on Freecharge Paylater transaction TCA
5% Cashback upto Rs 1550 on a minimum spend of Rs 1,500 with PayZappTCA