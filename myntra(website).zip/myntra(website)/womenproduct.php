<style>
        form{
            text-align: center;
            margin-left: 35%;
            margin-top: 50px;
        }
        tr td input{
            font-size: 17px;
            border-radius: 5px;
        }
        tr td{
            font-size: 20px;
        }
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
}

h1 {
    color: #333;
    font-size: 2rem;
    margin: 1rem 0;
}

form {
    width: 50%;
    margin: 0 auto;
    padding: 2rem;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}

form label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
}

form input[type="text"],
form input[type="email"],
form input[type="tel"],
form input[type="password"] {
    width: 100%;
    padding: 0.5rem;
    margin-bottom: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 1rem;
}

form input[type="submit"] {
    width: 100%;
    padding: 0.5rem;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1rem;
}

form input[type="submit"]:hover {
    background-color: #45a049;
}
    </style>

<?php
// include_once('men2.php');
?>

<form action="" method="post"enctype="multipart/form-data">
<table>
    <tr>
        <td colspan="2" style="font-size: 30px;">Product Insert Form !</td>
    </tr>
    <tr>
        <td>Product_Id:</td>
        <td> <input type="text" name="pid" required></td>
    </tr>
    <tr>
        <td>User_Id:</td>
        <td> <input type="text" name="User_id" required></td>
    </tr>
    <tr>
        <td>Product_Name:</td>
        <td> <input type="text" name="p_name" required></td>
    </tr>
    <tr>
        <td>Price:</td>
        <td><input type="text" name="price" required></td>
    </tr>
    <tr>
        <td>Product Pic:</td>
        <td><input type="file" name="pic" required></td>
    </tr>
    
    <tr>
        <td>Category:</td>
        <td><input type="text" name="c_name" required></td>
    </tr>
    

    <tr>
        <td colspan="2"><input type="submit" value="Upload" name="btn"  style="font-size: 20px; width: 70%; margin-left: 15%;"></td>
    </tr>
    
</table>
<?php
$con = mysqli_connect("localhost", "root", "", "forms");
if(isset($_POST['btn']))
{
$p_id = @$_POST['pid'];
$User_id = @$_POST['uid'];
$price = @$_POST['price'];
$cname = @$_POST['c_name'];
$p_name = @$_POST['p_name'];
$pic = @$_FILES['pic']['name'];



$q = "INSERT INTO womenproduct(Product_Id,User_id, Price, Category, P_Name, Product_picture) VALUES 
('$p_id','$User_id','$price','$cname','$p_name','$pic')";

    if(mysqli_query($con,$q))
    {
        move_uploaded_file($_FILES['pic']['tmp_name'],'images/'.$pic);
        ?>
        <script>
            alert("Pruduct Uploaded successful");
            window.location.href="women.php";
        </script>

<?php
    }
    else{

                ?>
        <script>
            alert("Product Inserted");
            window.location.href="women.php";
        </script>
        <?php
    }
    }


?>
