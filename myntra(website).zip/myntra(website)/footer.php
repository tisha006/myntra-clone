
<!-- Footer -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>

     .text-reset{
      text-decoration:none;
     }
    </style>
</head>

<br><br><br><hr style="color:lightgray;"><br><br><br><br><br><hr>

<footer class="text-center text-lg-start bg-body-white text-muted">

  <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
    

 
        
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
         
          <h6 class="text-uppercase fw-bold mb-4">
          ONLINE SHOPPING
          </h6>
          <p>
            <a href="#!" class="text-reset">Men</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Women</a>
          </p>
          <p>
          <a href="" class="text-reset">Home&Living</a>
          </p>
          <p>
            <a href="" class="text-reset">Beauty</a>
          </p>
          <p>
            <a href="" class="text-reset">Gifts Cards</a>
          </p>
        </div>
        <!-- Grid column -->





        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            CUSTOMER POLICIES
          </h6>
          <p>
            <a href="#!" class="text-reset">Contact Us</a>
          </p>
          <p>
          <p>
            <a href="" class="text-reset">FAQ</a>
          </p>
          <p>
            <a href="" class="text-reset">T&C</a>
          </p>
          <p>
            <a href="" class="text-reset">Shipping</a>
          </p>
        </div>
        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <a href="" class="text-reset">Pricing</a>
          </p>
          <p>
            <a href="" class="text-reset">Settings</a>
          </p>
          <p>
            <a href="" class="text-reset">Orders</a>
          </p>
         
        </div>
        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
          <p>India...</p>
          <p>
           </i>
            xyz@example.com
          </p>
          <p>+ 01 234 567 88</p>
          <p>+ 01 234 567 89</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  
</footer>
  <!-- Section: Links  -->
