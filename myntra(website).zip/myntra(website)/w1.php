<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="non_login/home_css.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>men</title>
    <style>
        

        .an {
            text-decoration: none;
            color: black;
        }
        .an:hover {
            text-decoration: none;
            color: black;
        }
        #cashpay{
            font-size: 15px;
            text-align: center;
            background-color:#ff3f6c;
            border: none;
            text-decoration: none;
            color: #fff;
            height: 35px;
            width: 55%;
            margin-top:50px;

            padding:7px;

           margin-left:1px;
            /* margin: auto; */
           
        }
        #cashpay:hover{
            background-color:#ff3f6c9a;
        }
        #cashpay2{
            font-size: 15px;
            text-align: center;
            background-color:#ff3f6c;
            border: none;
            text-decoration: none;
            color: #fff;
            height: 35px;
            width: 55%;
            margin-top:50%;
            padding:7px;
           margin-left:10px;
           
        }
        #cashpay2:hover{
            background-color:#ff3f6c9a;
        }
    </style>
</head>

<body>
    <?php include('navbar.php'); ?>
    
    <!-- Product Card fetching from database -->
    <div class="container">
        <div class="row bg-white py-5 ">
            <?php


$con = mysqli_connect("localhost", "root", "", "forms");
            $select_query = "select * from womenproduct";
            $result_query = mysqli_query($con, $select_query);
            while ($row = mysqli_fetch_array($result_query)) {
                $P_Name = $row[4];
                $Price = $row[2];
                $Product_picture = $row[5];
                $Product_id = $row[0];
            ?>

                <div class='col-xl-3 col-md-4 col-sm-6 mt-5'>
                    <a href="product_detail.php?product_id=<?php echo $product_id ?>" class="an">
                        <img class='card-image-top' src='images/<?php echo $Product_picture ?>'  width='82%' height='330px'>
                      
                        <div class='card-body'>
                            
                            <br><h5 style="font-size:15px;color:rgb(65, 61, 61);">Price: ₹<?php echo $Price ?></h5>
                            <h5 style="font-size:15px;color:rgb(65, 61, 61);margin-bottom:20px;"><?php echo $P_Name ?></h5>
                            <!-- &nbsp<strike>12</strike> &nbsp&nbsp&nbsp&nbsp&nbsp  -->
                    </a>
                    
                                <input type="hidden" name="product_id" value="<?php echo $row[0] ?>">
                                <div class='antima'>
                                    <?php
                                    if ($row[5] > 0) {
                                    ?>
                                        <a href="womenproductdetail.php?product_id=<?php echo $Product_id; ?>"ID="cashpay">Buy Now</a>
                                    <?php
                                    } else {
                                    ?>
                                         <br><a href="checkout.php"  ID="cashpay">Buy Now</a>
                                    <?php
                                    }
                                    ?>
                                   
                                   <a href="checkout.php"  ID="cashpay2">Add to Cart</a>
                                </div>
                    </form>
                </div>

        </div>
        

    <?php
            }
    ?>

    </div>
    </div>

    <?php
    include_once("footer.php")
    ?>
</body>

</html>
<?php
if(isset($_POST['cart'])){
?>
<script>
  window.location.href="login.php";
</script>
<?php
}
if(isset($_POST['buy'])){
  $Quantity=@$_POST['select'];
  ?>
  <script>
    window.location.href="login.php";
  </script>
  <?php
  }
?>